var class_data =
[
    [ "getValor", "class_data.html#a2d040be2799c23a0a3f745613a70bb43", null ],
    [ "setValor", "class_data.html#aee3a6598533a28a3f446c5f8ecb63c0f", null ]
];