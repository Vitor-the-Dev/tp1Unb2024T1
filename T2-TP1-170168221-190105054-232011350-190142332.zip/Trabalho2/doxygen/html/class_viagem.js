var class_viagem =
[
    [ "getAvaliacao", "class_viagem.html#a42db61ac0f02f1a84d7ca399b808577c", null ],
    [ "getCodigo", "class_viagem.html#aaf9cbace04be90c00e62d7b819abddd4", null ],
    [ "getNome", "class_viagem.html#a94988065b6782f723dfed72bd287c934", null ],
    [ "setAvaliacao", "class_viagem.html#a9360ea134ac9b4db39f2061839c964dd", null ],
    [ "setCodigo", "class_viagem.html#a0fb26b59d75e17786b61a3de4c9be82c", null ],
    [ "setNome", "class_viagem.html#abfc2bb24e426e94a6c831bbab2116030", null ]
];