var class_duracao =
[
    [ "getValor", "class_duracao.html#a5fd6f8ad02e0daa5b40341a27919c565", null ],
    [ "setValor", "class_duracao.html#ad4659398cd168f931fc00667ab45bc6f", null ]
];