var class_codigo =
[
    [ "getValor", "class_codigo.html#ae7dad73e010b3760cbd9310336c19aa2", null ],
    [ "setValor", "class_codigo.html#afdc4d9c6e42358cd0d48001d4c671584", null ]
];