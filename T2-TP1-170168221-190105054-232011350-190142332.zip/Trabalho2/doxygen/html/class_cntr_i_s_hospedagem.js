var class_cntr_i_s_hospedagem =
[
    [ "atualizar", "class_cntr_i_s_hospedagem.html#adfd4b2fcf04aff8ffafcd45103d7566f", null ],
    [ "criar", "class_cntr_i_s_hospedagem.html#a9238aeb157b6c8d8089d864fddd07cb3", null ],
    [ "excluir", "class_cntr_i_s_hospedagem.html#a0a6a3b6763a200d7007adeab8e0d8496", null ],
    [ "ler", "class_cntr_i_s_hospedagem.html#afbb1a84cdf186e1467150a5cef56b43a", null ],
    [ "listar", "class_cntr_i_s_hospedagem.html#ad5c819fe4a9460b1adddd1fd14968d57", null ]
];