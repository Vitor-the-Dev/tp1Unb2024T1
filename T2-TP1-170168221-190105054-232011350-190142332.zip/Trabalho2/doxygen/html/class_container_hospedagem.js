var class_container_hospedagem =
[
    [ "atualizar", "class_container_hospedagem.html#a377f2a8ab52c529a531236822af3aac4", null ],
    [ "criar", "class_container_hospedagem.html#ada2a4284032ab9da7e29fdcfb2faba85", null ],
    [ "excluir", "class_container_hospedagem.html#a52b71d13ce379cae6f32ad7e47147a06", null ],
    [ "ler", "class_container_hospedagem.html#a8d423ea16be37fb6684c99f775e4335a", null ],
    [ "listar", "class_container_hospedagem.html#a0dccaaa78691ad2f23f0458de00172c0", null ]
];