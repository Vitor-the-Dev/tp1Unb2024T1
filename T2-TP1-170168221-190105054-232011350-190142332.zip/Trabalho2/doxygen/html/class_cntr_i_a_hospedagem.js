var class_cntr_i_a_hospedagem =
[
    [ "atualizar", "class_cntr_i_a_hospedagem.html#ad36d6b212002207d173ca60631e0c089", null ],
    [ "criar", "class_cntr_i_a_hospedagem.html#a12504f9379d76b97e66ee84648800873", null ],
    [ "excluir", "class_cntr_i_a_hospedagem.html#a77a1a2713fb4abd40bfc1db5968dab52", null ],
    [ "ler", "class_cntr_i_a_hospedagem.html#a1423b5a03e997383ca80b27c3e64487a", null ],
    [ "listar", "class_cntr_i_a_hospedagem.html#a0bd45dc1e9a2bfbc118ea7f9876aa595", null ]
];