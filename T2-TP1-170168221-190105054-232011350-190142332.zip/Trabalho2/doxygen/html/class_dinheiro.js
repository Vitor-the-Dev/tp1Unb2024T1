var class_dinheiro =
[
    [ "getValor", "class_dinheiro.html#af1ec499768686c152ea490204fbc4e64", null ],
    [ "setValor", "class_dinheiro.html#a8ad37a325f3479c2348e5812a2637d99", null ]
];