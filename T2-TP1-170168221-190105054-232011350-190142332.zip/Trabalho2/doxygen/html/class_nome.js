var class_nome =
[
    [ "getValor", "class_nome.html#ac8881234a0e2d0ddff4fb689ceb256eb", null ],
    [ "setValor", "class_nome.html#aaad6a1ad8718cce8dde090a435c3cd81", null ]
];