var class_hospedagem =
[
    [ "getAvaliacao", "class_hospedagem.html#a25d434bffc9f888c7d138788a72e6304", null ],
    [ "getCodigo", "class_hospedagem.html#a0bc571395f18c1c0a62409a0f7a0a7f1", null ],
    [ "getDiaria", "class_hospedagem.html#a0b69b10783f7795dccef73dc2d27efb0", null ],
    [ "getNome", "class_hospedagem.html#acd15abdd2f7f04dcd5f93c466e9f9800", null ],
    [ "setAvaliacao", "class_hospedagem.html#ae5fcdaf3cd938dfc5bbb04d6b0800a3a", null ],
    [ "setCodigo", "class_hospedagem.html#ac141713d5120896850ffa1e70d600ab2", null ],
    [ "setDiaria", "class_hospedagem.html#a531c896140415fbedaa0255571fba1fb", null ],
    [ "setNome", "class_hospedagem.html#af25ae1a5ebf2faeb3e1613adec071b8a", null ]
];