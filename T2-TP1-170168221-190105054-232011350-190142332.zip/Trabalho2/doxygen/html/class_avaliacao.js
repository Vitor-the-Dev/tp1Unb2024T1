var class_avaliacao =
[
    [ "getValor", "class_avaliacao.html#a31e7d5be1f978469887751abbdd13a65", null ],
    [ "setValor", "class_avaliacao.html#a3f2776f1f13da9557727eedfb9d82c9a", null ]
];